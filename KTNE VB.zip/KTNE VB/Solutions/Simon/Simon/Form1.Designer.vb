﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Simon
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Simon))
        Me.btnVowel = New System.Windows.Forms.Button()
        Me.lblVowel = New System.Windows.Forms.Label()
        Me.btnNoVowel = New System.Windows.Forms.Button()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btnRoot = New System.Windows.Forms.ToolStripButton()
        Me.lblSts1 = New System.Windows.Forms.ToolStripLabel()
        Me.lblStrikes = New System.Windows.Forms.Label()
        Me.btnNone = New System.Windows.Forms.Button()
        Me.btnOne = New System.Windows.Forms.Button()
        Me.btnTwo = New System.Windows.Forms.Button()
        Me.btnRed = New System.Windows.Forms.Button()
        Me.btnBlue = New System.Windows.Forms.Button()
        Me.btnGreen = New System.Windows.Forms.Button()
        Me.btnYellow = New System.Windows.Forms.Button()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnVowel
        '
        Me.btnVowel.Location = New System.Drawing.Point(39, 50)
        Me.btnVowel.Name = "btnVowel"
        Me.btnVowel.Size = New System.Drawing.Size(75, 23)
        Me.btnVowel.TabIndex = 0
        Me.btnVowel.Text = "Vowel"
        Me.btnVowel.UseVisualStyleBackColor = True
        '
        'lblVowel
        '
        Me.lblVowel.AutoSize = True
        Me.lblVowel.Location = New System.Drawing.Point(36, 25)
        Me.lblVowel.Name = "lblVowel"
        Me.lblVowel.Size = New System.Drawing.Size(199, 13)
        Me.lblVowel.TabIndex = 1
        Me.lblVowel.Text = "Does the serial number contain a vowel?"
        '
        'btnNoVowel
        '
        Me.btnNoVowel.Location = New System.Drawing.Point(149, 50)
        Me.btnNoVowel.Name = "btnNoVowel"
        Me.btnNoVowel.Size = New System.Drawing.Size(75, 23)
        Me.btnNoVowel.TabIndex = 2
        Me.btnNoVowel.Text = "No Vowel"
        Me.btnNoVowel.UseVisualStyleBackColor = True
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnRoot, Me.lblSts1})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(274, 25)
        Me.ToolStrip1.TabIndex = 3
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btnRoot
        '
        Me.btnRoot.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnRoot.Image = CType(resources.GetObject("btnRoot.Image"), System.Drawing.Image)
        Me.btnRoot.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnRoot.Name = "btnRoot"
        Me.btnRoot.Size = New System.Drawing.Size(36, 22)
        Me.btnRoot.Text = "Root"
        '
        'lblSts1
        '
        Me.lblSts1.Name = "lblSts1"
        Me.lblSts1.Size = New System.Drawing.Size(0, 22)
        '
        'lblStrikes
        '
        Me.lblStrikes.AutoSize = True
        Me.lblStrikes.Location = New System.Drawing.Point(57, 90)
        Me.lblStrikes.Name = "lblStrikes"
        Me.lblStrikes.Size = New System.Drawing.Size(158, 13)
        Me.lblStrikes.TabIndex = 4
        Me.lblStrikes.Text = "How many strikes do you have?"
        '
        'btnNone
        '
        Me.btnNone.Location = New System.Drawing.Point(12, 115)
        Me.btnNone.Name = "btnNone"
        Me.btnNone.Size = New System.Drawing.Size(75, 23)
        Me.btnNone.TabIndex = 5
        Me.btnNone.Text = "None"
        Me.btnNone.UseVisualStyleBackColor = True
        '
        'btnOne
        '
        Me.btnOne.Location = New System.Drawing.Point(93, 115)
        Me.btnOne.Name = "btnOne"
        Me.btnOne.Size = New System.Drawing.Size(75, 23)
        Me.btnOne.TabIndex = 6
        Me.btnOne.Text = "One"
        Me.btnOne.UseVisualStyleBackColor = True
        '
        'btnTwo
        '
        Me.btnTwo.Location = New System.Drawing.Point(174, 115)
        Me.btnTwo.Name = "btnTwo"
        Me.btnTwo.Size = New System.Drawing.Size(75, 23)
        Me.btnTwo.TabIndex = 7
        Me.btnTwo.Text = "Two"
        Me.btnTwo.UseVisualStyleBackColor = True
        '
        'btnRed
        '
        Me.btnRed.Location = New System.Drawing.Point(39, 172)
        Me.btnRed.Name = "btnRed"
        Me.btnRed.Size = New System.Drawing.Size(75, 23)
        Me.btnRed.TabIndex = 8
        Me.btnRed.Text = "Red"
        Me.btnRed.UseVisualStyleBackColor = True
        '
        'btnBlue
        '
        Me.btnBlue.Location = New System.Drawing.Point(149, 172)
        Me.btnBlue.Name = "btnBlue"
        Me.btnBlue.Size = New System.Drawing.Size(75, 23)
        Me.btnBlue.TabIndex = 9
        Me.btnBlue.Text = "Blue"
        Me.btnBlue.UseVisualStyleBackColor = True
        '
        'btnGreen
        '
        Me.btnGreen.Location = New System.Drawing.Point(39, 221)
        Me.btnGreen.Name = "btnGreen"
        Me.btnGreen.Size = New System.Drawing.Size(75, 23)
        Me.btnGreen.TabIndex = 10
        Me.btnGreen.Text = "Green"
        Me.btnGreen.UseVisualStyleBackColor = True
        '
        'btnYellow
        '
        Me.btnYellow.Location = New System.Drawing.Point(149, 221)
        Me.btnYellow.Name = "btnYellow"
        Me.btnYellow.Size = New System.Drawing.Size(75, 23)
        Me.btnYellow.TabIndex = 11
        Me.btnYellow.Text = "Yellow"
        Me.btnYellow.UseVisualStyleBackColor = True
        '
        'ListView1
        '
        Me.ListView1.Location = New System.Drawing.Point(12, 250)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(250, 130)
        Me.ListView1.TabIndex = 12
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(93, 386)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 13
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'Simon
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(274, 420)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.btnYellow)
        Me.Controls.Add(Me.btnGreen)
        Me.Controls.Add(Me.btnBlue)
        Me.Controls.Add(Me.btnRed)
        Me.Controls.Add(Me.btnTwo)
        Me.Controls.Add(Me.btnOne)
        Me.Controls.Add(Me.btnNone)
        Me.Controls.Add(Me.lblStrikes)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.btnNoVowel)
        Me.Controls.Add(Me.lblVowel)
        Me.Controls.Add(Me.btnVowel)
        Me.Name = "Simon"
        Me.Text = "Simon"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnVowel As System.Windows.Forms.Button
    Friend WithEvents lblVowel As System.Windows.Forms.Label
    Friend WithEvents btnNoVowel As System.Windows.Forms.Button
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents btnRoot As System.Windows.Forms.ToolStripButton
    Friend WithEvents lblStrikes As System.Windows.Forms.Label
    Friend WithEvents btnNone As System.Windows.Forms.Button
    Friend WithEvents btnOne As System.Windows.Forms.Button
    Friend WithEvents btnTwo As System.Windows.Forms.Button
    Friend WithEvents btnRed As System.Windows.Forms.Button
    Friend WithEvents btnBlue As System.Windows.Forms.Button
    Friend WithEvents btnGreen As System.Windows.Forms.Button
    Friend WithEvents btnYellow As System.Windows.Forms.Button
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents lblSts1 As System.Windows.Forms.ToolStripLabel

End Class
