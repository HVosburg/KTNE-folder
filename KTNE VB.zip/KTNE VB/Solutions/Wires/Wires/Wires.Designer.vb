﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWires
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmWires))
        Me.lstWires = New System.Windows.Forms.ListView()
        Me.WiresRed = New System.Windows.Forms.Button()
        Me.WiresYellow = New System.Windows.Forms.Button()
        Me.WiresWhite = New System.Windows.Forms.Button()
        Me.WiresBlue = New System.Windows.Forms.Button()
        Me.WiresBlack = New System.Windows.Forms.Button()
        Me.WiresConfirm = New System.Windows.Forms.Button()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btnRoot = New System.Windows.Forms.ToolStripButton()
        Me.lblStatus = New System.Windows.Forms.ToolStripLabel()
        Me.WiresSerialEven = New System.Windows.Forms.Button()
        Me.WiresSerialOdd = New System.Windows.Forms.Button()
        Me.WiresReset = New System.Windows.Forms.Button()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lstWires
        '
        Me.lstWires.Location = New System.Drawing.Point(12, 28)
        Me.lstWires.Name = "lstWires"
        Me.lstWires.Size = New System.Drawing.Size(260, 159)
        Me.lstWires.TabIndex = 0
        Me.lstWires.UseCompatibleStateImageBehavior = False
        Me.lstWires.View = System.Windows.Forms.View.List
        '
        'WiresRed
        '
        Me.WiresRed.Location = New System.Drawing.Point(12, 193)
        Me.WiresRed.Name = "WiresRed"
        Me.WiresRed.Size = New System.Drawing.Size(75, 23)
        Me.WiresRed.TabIndex = 1
        Me.WiresRed.Text = "Red"
        Me.WiresRed.UseVisualStyleBackColor = True
        '
        'WiresYellow
        '
        Me.WiresYellow.Location = New System.Drawing.Point(104, 193)
        Me.WiresYellow.Name = "WiresYellow"
        Me.WiresYellow.Size = New System.Drawing.Size(75, 23)
        Me.WiresYellow.TabIndex = 2
        Me.WiresYellow.Text = "Yellow"
        Me.WiresYellow.UseVisualStyleBackColor = True
        '
        'WiresWhite
        '
        Me.WiresWhite.Location = New System.Drawing.Point(197, 193)
        Me.WiresWhite.Name = "WiresWhite"
        Me.WiresWhite.Size = New System.Drawing.Size(75, 23)
        Me.WiresWhite.TabIndex = 3
        Me.WiresWhite.Text = "White"
        Me.WiresWhite.UseVisualStyleBackColor = True
        '
        'WiresBlue
        '
        Me.WiresBlue.Location = New System.Drawing.Point(12, 222)
        Me.WiresBlue.Name = "WiresBlue"
        Me.WiresBlue.Size = New System.Drawing.Size(75, 23)
        Me.WiresBlue.TabIndex = 4
        Me.WiresBlue.Text = "Blue"
        Me.WiresBlue.UseVisualStyleBackColor = True
        '
        'WiresBlack
        '
        Me.WiresBlack.Location = New System.Drawing.Point(104, 222)
        Me.WiresBlack.Name = "WiresBlack"
        Me.WiresBlack.Size = New System.Drawing.Size(75, 23)
        Me.WiresBlack.TabIndex = 5
        Me.WiresBlack.Text = "Black"
        Me.WiresBlack.UseVisualStyleBackColor = True
        '
        'WiresConfirm
        '
        Me.WiresConfirm.Location = New System.Drawing.Point(197, 222)
        Me.WiresConfirm.Name = "WiresConfirm"
        Me.WiresConfirm.Size = New System.Drawing.Size(75, 23)
        Me.WiresConfirm.TabIndex = 6
        Me.WiresConfirm.Text = "Confirm"
        Me.WiresConfirm.UseVisualStyleBackColor = True
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnRoot, Me.lblStatus})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(284, 25)
        Me.ToolStrip1.TabIndex = 7
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btnRoot
        '
        Me.btnRoot.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnRoot.Image = CType(resources.GetObject("btnRoot.Image"), System.Drawing.Image)
        Me.btnRoot.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnRoot.Name = "btnRoot"
        Me.btnRoot.Size = New System.Drawing.Size(36, 22)
        Me.btnRoot.Text = "Root"
        '
        'lblStatus
        '
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(0, 22)
        '
        'WiresSerialEven
        '
        Me.WiresSerialEven.Location = New System.Drawing.Point(12, 251)
        Me.WiresSerialEven.Name = "WiresSerialEven"
        Me.WiresSerialEven.Size = New System.Drawing.Size(75, 23)
        Me.WiresSerialEven.TabIndex = 8
        Me.WiresSerialEven.Text = "Even"
        Me.WiresSerialEven.UseVisualStyleBackColor = True
        '
        'WiresSerialOdd
        '
        Me.WiresSerialOdd.Location = New System.Drawing.Point(104, 251)
        Me.WiresSerialOdd.Name = "WiresSerialOdd"
        Me.WiresSerialOdd.Size = New System.Drawing.Size(75, 23)
        Me.WiresSerialOdd.TabIndex = 9
        Me.WiresSerialOdd.Text = "Odd"
        Me.WiresSerialOdd.UseVisualStyleBackColor = True
        '
        'WiresReset
        '
        Me.WiresReset.Location = New System.Drawing.Point(197, 251)
        Me.WiresReset.Name = "WiresReset"
        Me.WiresReset.Size = New System.Drawing.Size(75, 23)
        Me.WiresReset.TabIndex = 10
        Me.WiresReset.Text = "Reset"
        Me.WiresReset.UseVisualStyleBackColor = True
        '
        'frmWires
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 286)
        Me.Controls.Add(Me.WiresReset)
        Me.Controls.Add(Me.WiresSerialOdd)
        Me.Controls.Add(Me.WiresSerialEven)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.WiresConfirm)
        Me.Controls.Add(Me.WiresBlack)
        Me.Controls.Add(Me.WiresBlue)
        Me.Controls.Add(Me.WiresWhite)
        Me.Controls.Add(Me.WiresYellow)
        Me.Controls.Add(Me.WiresRed)
        Me.Controls.Add(Me.lstWires)
        Me.Name = "frmWires"
        Me.Text = "Wires"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lstWires As System.Windows.Forms.ListView
    Friend WithEvents WiresRed As System.Windows.Forms.Button
    Friend WithEvents WiresYellow As System.Windows.Forms.Button
    Friend WithEvents WiresWhite As System.Windows.Forms.Button
    Friend WithEvents WiresBlue As System.Windows.Forms.Button
    Friend WithEvents WiresBlack As System.Windows.Forms.Button
    Friend WithEvents WiresConfirm As System.Windows.Forms.Button
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents btnRoot As System.Windows.Forms.ToolStripButton
    Friend WithEvents WiresSerialEven As System.Windows.Forms.Button
    Friend WithEvents WiresSerialOdd As System.Windows.Forms.Button
    Friend WithEvents WiresReset As System.Windows.Forms.Button
    Friend WithEvents lblStatus As System.Windows.Forms.ToolStripLabel

End Class
