﻿Public Class frmButton

    Dim strColor As String
    Dim strWord As String
    Dim intBat As Integer
    Dim blnCAR As Boolean
    Dim blnFRK As Boolean

    Sub BatCount()
        If rdo01.Checked = True Then
            intBat = 1
        ElseIf rdo2.Checked = True Then
            intBat = 2
        ElseIf rdo34.Checked = True Then
            intBat = 3
        End If
    End Sub

    Sub BlnChk()
        blnCAR = chkCAR.Checked
        blnFRK = chkFRK.Checked
    End Sub

    Sub ButtonCalc()

        BatCount()
        BlnChk()

        If strColor = "Blue" And strWord = "Abort" Then
            lblStatus.Text = "Hold - Blue:4 Yellow:5 Other:1"


        ElseIf intBat > 1 And strWord = "Detonate" Then
                lblStatus.Text = "Press and immediatly release"


        ElseIf strColor = "White" And blnCAR = True Then
            lblStatus.Text = "Hold - Blue:4 Yellow:5 Other:1"


        ElseIf intBat > 2 And blnFRK = True Then
            lblStatus.Text = "Press and immediatly release"


        ElseIf strColor = "Yellow" Then
            lblStatus.Text = "Hold - Blue:4 Yellow:5 Other:1"


        ElseIf strColor = "Red" And strWord = "Hold" Then
            lblStatus.Text = "Press and immediatly release"


        Else
            lblStatus.Text = "Hold - Blue:4 Yellow:5 Other:1"

        End If

    End Sub

    Private Sub btnBlue_Click(sender As Object, e As EventArgs) Handles btnBlue.Click
        strColor = "Blue"
    End Sub

    Private Sub btnWhite_Click(sender As Object, e As EventArgs) Handles btnWhite.Click
        strColor = "White"
    End Sub

    Private Sub btnYellow_Click(sender As Object, e As EventArgs) Handles btnYellow.Click
        strColor = "Yellow"
    End Sub

    Private Sub btnRed_Click(sender As Object, e As EventArgs) Handles btnRed.Click
        strColor = "Red"
    End Sub

    Private Sub btnAbort_Click(sender As Object, e As EventArgs) Handles btnAbort.Click
        strWord = "Abort"
    End Sub

    Private Sub btnDetonate_Click(sender As Object, e As EventArgs) Handles btnDetonate.Click
        strWord = "Detonate"
    End Sub

    Private Sub btnHold_Click(sender As Object, e As EventArgs) Handles btnHold.Click
        strWord = "Hold"
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        lblStatus.Text = "Please enter all fields"
        strColor = ""
        strWord = ""
        intBat =
        blnCAR = False
        blnFRK = False
        chkCAR.Checked = False
        chkFRK.Checked = False
        rdo01.Checked = False
        rdo2.Checked = False
        rdo34.Checked = False
    End Sub


    Private Sub btnConfirm_Click(sender As Object, e As EventArgs) Handles btnConfirm.Click
        ButtonCalc()
    End Sub
End Class
