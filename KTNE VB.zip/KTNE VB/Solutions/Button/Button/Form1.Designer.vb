﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmButton
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmButton))
        Me.btnBlue = New System.Windows.Forms.Button()
        Me.btnWhite = New System.Windows.Forms.Button()
        Me.btnYellow = New System.Windows.Forms.Button()
        Me.btnRed = New System.Windows.Forms.Button()
        Me.btnAbort = New System.Windows.Forms.Button()
        Me.btnDetonate = New System.Windows.Forms.Button()
        Me.btnHold = New System.Windows.Forms.Button()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btnRoot = New System.Windows.Forms.ToolStripButton()
        Me.lblStatus = New System.Windows.Forms.ToolStripLabel()
        Me.rdo01 = New System.Windows.Forms.RadioButton()
        Me.lblBat = New System.Windows.Forms.Label()
        Me.rdo2 = New System.Windows.Forms.RadioButton()
        Me.rdo34 = New System.Windows.Forms.RadioButton()
        Me.lblIndicators = New System.Windows.Forms.Label()
        Me.chkFRK = New System.Windows.Forms.CheckBox()
        Me.chkCAR = New System.Windows.Forms.CheckBox()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnConfirm = New System.Windows.Forms.Button()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnBlue
        '
        Me.btnBlue.Location = New System.Drawing.Point(12, 28)
        Me.btnBlue.Name = "btnBlue"
        Me.btnBlue.Size = New System.Drawing.Size(75, 23)
        Me.btnBlue.TabIndex = 0
        Me.btnBlue.Text = "Blue"
        Me.btnBlue.UseVisualStyleBackColor = True
        '
        'btnWhite
        '
        Me.btnWhite.Location = New System.Drawing.Point(12, 57)
        Me.btnWhite.Name = "btnWhite"
        Me.btnWhite.Size = New System.Drawing.Size(75, 23)
        Me.btnWhite.TabIndex = 1
        Me.btnWhite.Text = "White"
        Me.btnWhite.UseVisualStyleBackColor = True
        '
        'btnYellow
        '
        Me.btnYellow.Location = New System.Drawing.Point(12, 86)
        Me.btnYellow.Name = "btnYellow"
        Me.btnYellow.Size = New System.Drawing.Size(75, 23)
        Me.btnYellow.TabIndex = 2
        Me.btnYellow.Text = "Yellow"
        Me.btnYellow.UseVisualStyleBackColor = True
        '
        'btnRed
        '
        Me.btnRed.Location = New System.Drawing.Point(12, 115)
        Me.btnRed.Name = "btnRed"
        Me.btnRed.Size = New System.Drawing.Size(75, 23)
        Me.btnRed.TabIndex = 3
        Me.btnRed.Text = "Red"
        Me.btnRed.UseVisualStyleBackColor = True
        '
        'btnAbort
        '
        Me.btnAbort.Location = New System.Drawing.Point(161, 28)
        Me.btnAbort.Name = "btnAbort"
        Me.btnAbort.Size = New System.Drawing.Size(75, 23)
        Me.btnAbort.TabIndex = 4
        Me.btnAbort.Text = "Abort"
        Me.btnAbort.UseVisualStyleBackColor = True
        '
        'btnDetonate
        '
        Me.btnDetonate.Location = New System.Drawing.Point(161, 57)
        Me.btnDetonate.Name = "btnDetonate"
        Me.btnDetonate.Size = New System.Drawing.Size(75, 23)
        Me.btnDetonate.TabIndex = 5
        Me.btnDetonate.Text = "Detonate"
        Me.btnDetonate.UseVisualStyleBackColor = True
        '
        'btnHold
        '
        Me.btnHold.Location = New System.Drawing.Point(161, 86)
        Me.btnHold.Name = "btnHold"
        Me.btnHold.Size = New System.Drawing.Size(75, 23)
        Me.btnHold.TabIndex = 6
        Me.btnHold.Text = "Hold"
        Me.btnHold.UseVisualStyleBackColor = True
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnRoot, Me.lblStatus})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(284, 25)
        Me.ToolStrip1.TabIndex = 7
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btnRoot
        '
        Me.btnRoot.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnRoot.Image = CType(resources.GetObject("btnRoot.Image"), System.Drawing.Image)
        Me.btnRoot.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnRoot.Name = "btnRoot"
        Me.btnRoot.Size = New System.Drawing.Size(36, 22)
        Me.btnRoot.Text = "Root"
        '
        'lblStatus
        '
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(116, 22)
        Me.lblStatus.Text = "Please enter all fields"
        '
        'rdo01
        '
        Me.rdo01.AutoSize = True
        Me.rdo01.Location = New System.Drawing.Point(24, 157)
        Me.rdo01.Name = "rdo01"
        Me.rdo01.Size = New System.Drawing.Size(40, 17)
        Me.rdo01.TabIndex = 8
        Me.rdo01.TabStop = True
        Me.rdo01.Text = "0-1"
        Me.rdo01.UseVisualStyleBackColor = True
        '
        'lblBat
        '
        Me.lblBat.AutoSize = True
        Me.lblBat.Location = New System.Drawing.Point(23, 141)
        Me.lblBat.Name = "lblBat"
        Me.lblBat.Size = New System.Drawing.Size(48, 13)
        Me.lblBat.TabIndex = 9
        Me.lblBat.Text = "Batteries"
        '
        'rdo2
        '
        Me.rdo2.AutoSize = True
        Me.rdo2.Location = New System.Drawing.Point(26, 180)
        Me.rdo2.Name = "rdo2"
        Me.rdo2.Size = New System.Drawing.Size(31, 17)
        Me.rdo2.TabIndex = 10
        Me.rdo2.TabStop = True
        Me.rdo2.Text = "2"
        Me.rdo2.UseVisualStyleBackColor = True
        '
        'rdo34
        '
        Me.rdo34.AutoSize = True
        Me.rdo34.Location = New System.Drawing.Point(26, 203)
        Me.rdo34.Name = "rdo34"
        Me.rdo34.Size = New System.Drawing.Size(40, 17)
        Me.rdo34.TabIndex = 11
        Me.rdo34.TabStop = True
        Me.rdo34.Text = "> 2"
        Me.rdo34.UseVisualStyleBackColor = True
        '
        'lblIndicators
        '
        Me.lblIndicators.AutoSize = True
        Me.lblIndicators.Location = New System.Drawing.Point(170, 141)
        Me.lblIndicators.Name = "lblIndicators"
        Me.lblIndicators.Size = New System.Drawing.Size(53, 13)
        Me.lblIndicators.TabIndex = 12
        Me.lblIndicators.Text = "Indicators"
        '
        'chkFRK
        '
        Me.chkFRK.AutoSize = True
        Me.chkFRK.Location = New System.Drawing.Point(173, 177)
        Me.chkFRK.Name = "chkFRK"
        Me.chkFRK.Size = New System.Drawing.Size(47, 17)
        Me.chkFRK.TabIndex = 14
        Me.chkFRK.Text = "FRK"
        Me.chkFRK.UseVisualStyleBackColor = True
        '
        'chkCAR
        '
        Me.chkCAR.AutoSize = True
        Me.chkCAR.Location = New System.Drawing.Point(173, 157)
        Me.chkCAR.Name = "chkCAR"
        Me.chkCAR.Size = New System.Drawing.Size(48, 17)
        Me.chkCAR.TabIndex = 15
        Me.chkCAR.Text = "CAR"
        Me.chkCAR.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(161, 115)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 16
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnConfirm
        '
        Me.btnConfirm.Location = New System.Drawing.Point(161, 200)
        Me.btnConfirm.Name = "btnConfirm"
        Me.btnConfirm.Size = New System.Drawing.Size(75, 23)
        Me.btnConfirm.TabIndex = 17
        Me.btnConfirm.Text = "Confirm"
        Me.btnConfirm.UseVisualStyleBackColor = True
        '
        'frmButton
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 262)
        Me.Controls.Add(Me.btnConfirm)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.chkCAR)
        Me.Controls.Add(Me.chkFRK)
        Me.Controls.Add(Me.lblIndicators)
        Me.Controls.Add(Me.rdo34)
        Me.Controls.Add(Me.rdo2)
        Me.Controls.Add(Me.lblBat)
        Me.Controls.Add(Me.rdo01)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.btnHold)
        Me.Controls.Add(Me.btnDetonate)
        Me.Controls.Add(Me.btnAbort)
        Me.Controls.Add(Me.btnRed)
        Me.Controls.Add(Me.btnYellow)
        Me.Controls.Add(Me.btnWhite)
        Me.Controls.Add(Me.btnBlue)
        Me.Name = "frmButton"
        Me.Text = "Button"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnBlue As System.Windows.Forms.Button
    Friend WithEvents btnWhite As System.Windows.Forms.Button
    Friend WithEvents btnYellow As System.Windows.Forms.Button
    Friend WithEvents btnRed As System.Windows.Forms.Button
    Friend WithEvents btnAbort As System.Windows.Forms.Button
    Friend WithEvents btnDetonate As System.Windows.Forms.Button
    Friend WithEvents btnHold As System.Windows.Forms.Button
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents btnRoot As System.Windows.Forms.ToolStripButton
    Friend WithEvents lblStatus As System.Windows.Forms.ToolStripLabel
    Friend WithEvents rdo01 As System.Windows.Forms.RadioButton
    Friend WithEvents lblBat As System.Windows.Forms.Label
    Friend WithEvents rdo2 As System.Windows.Forms.RadioButton
    Friend WithEvents rdo34 As System.Windows.Forms.RadioButton
    Friend WithEvents lblIndicators As System.Windows.Forms.Label
    Friend WithEvents chkFRK As System.Windows.Forms.CheckBox
    Friend WithEvents chkCAR As System.Windows.Forms.CheckBox
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents btnConfirm As System.Windows.Forms.Button

End Class
