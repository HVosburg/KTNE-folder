﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmKeypads
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmKeypads))
        Me.picCopyright = New System.Windows.Forms.PictureBox()
        Me.picFilledstar = New System.Windows.Forms.PictureBox()
        Me.picHollowstar = New System.Windows.Forms.PictureBox()
        Me.picSmileyface = New System.Windows.Forms.PictureBox()
        Me.picDoublek = New System.Windows.Forms.PictureBox()
        Me.picOmega = New System.Windows.Forms.PictureBox()
        Me.picSquidknife = New System.Windows.Forms.PictureBox()
        Me.picPumpkin = New System.Windows.Forms.PictureBox()
        Me.picHookn = New System.Windows.Forms.PictureBox()
        Me.picSix = New System.Windows.Forms.PictureBox()
        Me.picSquigglyn = New System.Windows.Forms.PictureBox()
        Me.picAt = New System.Windows.Forms.PictureBox()
        Me.picAe = New System.Windows.Forms.PictureBox()
        Me.picMeltedthree = New System.Windows.Forms.PictureBox()
        Me.picEuro = New System.Windows.Forms.PictureBox()
        Me.picNwithhat = New System.Windows.Forms.PictureBox()
        Me.picDragon = New System.Windows.Forms.PictureBox()
        Me.picQuestionmark = New System.Windows.Forms.PictureBox()
        Me.picParagraph = New System.Windows.Forms.PictureBox()
        Me.picRightc = New System.Windows.Forms.PictureBox()
        Me.picLeftc = New System.Windows.Forms.PictureBox()
        Me.picPitchfork = New System.Windows.Forms.PictureBox()
        Me.picCursive = New System.Windows.Forms.PictureBox()
        Me.picTracks = New System.Windows.Forms.PictureBox()
        Me.picBalloon = New System.Windows.Forms.PictureBox()
        Me.picUpsidedowny = New System.Windows.Forms.PictureBox()
        Me.picBt = New System.Windows.Forms.PictureBox()
        Me.picAns1 = New System.Windows.Forms.PictureBox()
        Me.picAns2 = New System.Windows.Forms.PictureBox()
        Me.picAns3 = New System.Windows.Forms.PictureBox()
        Me.picAns4 = New System.Windows.Forms.PictureBox()
        Me.lstKp = New System.Windows.Forms.ListView()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.lbl1 = New System.Windows.Forms.ToolStripLabel()
        CType(Me.picCopyright, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFilledstar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picHollowstar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSmileyface, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDoublek, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picOmega, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSquidknife, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPumpkin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picHookn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSix, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSquigglyn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAe, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMeltedthree, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEuro, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picNwithhat, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDragon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picQuestionmark, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picParagraph, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRightc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLeftc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPitchfork, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCursive, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTracks, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBalloon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picUpsidedowny, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAns1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAns2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAns3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAns4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'picCopyright
        '
        Me.picCopyright.Image = CType(resources.GetObject("picCopyright.Image"), System.Drawing.Image)
        Me.picCopyright.Location = New System.Drawing.Point(12, 214)
        Me.picCopyright.Name = "picCopyright"
        Me.picCopyright.Size = New System.Drawing.Size(52, 40)
        Me.picCopyright.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picCopyright.TabIndex = 0
        Me.picCopyright.TabStop = False
        '
        'picFilledstar
        '
        Me.picFilledstar.Image = CType(resources.GetObject("picFilledstar.Image"), System.Drawing.Image)
        Me.picFilledstar.Location = New System.Drawing.Point(70, 214)
        Me.picFilledstar.Name = "picFilledstar"
        Me.picFilledstar.Size = New System.Drawing.Size(52, 40)
        Me.picFilledstar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFilledstar.TabIndex = 1
        Me.picFilledstar.TabStop = False
        '
        'picHollowstar
        '
        Me.picHollowstar.Image = CType(resources.GetObject("picHollowstar.Image"), System.Drawing.Image)
        Me.picHollowstar.Location = New System.Drawing.Point(128, 214)
        Me.picHollowstar.Name = "picHollowstar"
        Me.picHollowstar.Size = New System.Drawing.Size(52, 40)
        Me.picHollowstar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picHollowstar.TabIndex = 2
        Me.picHollowstar.TabStop = False
        '
        'picSmileyface
        '
        Me.picSmileyface.Image = CType(resources.GetObject("picSmileyface.Image"), System.Drawing.Image)
        Me.picSmileyface.Location = New System.Drawing.Point(186, 214)
        Me.picSmileyface.Name = "picSmileyface"
        Me.picSmileyface.Size = New System.Drawing.Size(52, 40)
        Me.picSmileyface.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picSmileyface.TabIndex = 3
        Me.picSmileyface.TabStop = False
        '
        'picDoublek
        '
        Me.picDoublek.Image = CType(resources.GetObject("picDoublek.Image"), System.Drawing.Image)
        Me.picDoublek.Location = New System.Drawing.Point(244, 214)
        Me.picDoublek.Name = "picDoublek"
        Me.picDoublek.Size = New System.Drawing.Size(52, 40)
        Me.picDoublek.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picDoublek.TabIndex = 4
        Me.picDoublek.TabStop = False
        '
        'picOmega
        '
        Me.picOmega.Image = CType(resources.GetObject("picOmega.Image"), System.Drawing.Image)
        Me.picOmega.Location = New System.Drawing.Point(12, 260)
        Me.picOmega.Name = "picOmega"
        Me.picOmega.Size = New System.Drawing.Size(52, 40)
        Me.picOmega.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picOmega.TabIndex = 5
        Me.picOmega.TabStop = False
        '
        'picSquidknife
        '
        Me.picSquidknife.Image = CType(resources.GetObject("picSquidknife.Image"), System.Drawing.Image)
        Me.picSquidknife.Location = New System.Drawing.Point(70, 260)
        Me.picSquidknife.Name = "picSquidknife"
        Me.picSquidknife.Size = New System.Drawing.Size(52, 40)
        Me.picSquidknife.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picSquidknife.TabIndex = 6
        Me.picSquidknife.TabStop = False
        '
        'picPumpkin
        '
        Me.picPumpkin.Image = CType(resources.GetObject("picPumpkin.Image"), System.Drawing.Image)
        Me.picPumpkin.Location = New System.Drawing.Point(128, 260)
        Me.picPumpkin.Name = "picPumpkin"
        Me.picPumpkin.Size = New System.Drawing.Size(52, 40)
        Me.picPumpkin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picPumpkin.TabIndex = 7
        Me.picPumpkin.TabStop = False
        '
        'picHookn
        '
        Me.picHookn.Image = CType(resources.GetObject("picHookn.Image"), System.Drawing.Image)
        Me.picHookn.Location = New System.Drawing.Point(186, 260)
        Me.picHookn.Name = "picHookn"
        Me.picHookn.Size = New System.Drawing.Size(52, 40)
        Me.picHookn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picHookn.TabIndex = 8
        Me.picHookn.TabStop = False
        '
        'picSix
        '
        Me.picSix.Image = CType(resources.GetObject("picSix.Image"), System.Drawing.Image)
        Me.picSix.Location = New System.Drawing.Point(244, 260)
        Me.picSix.Name = "picSix"
        Me.picSix.Size = New System.Drawing.Size(52, 40)
        Me.picSix.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picSix.TabIndex = 9
        Me.picSix.TabStop = False
        '
        'picSquigglyn
        '
        Me.picSquigglyn.Image = CType(resources.GetObject("picSquigglyn.Image"), System.Drawing.Image)
        Me.picSquigglyn.Location = New System.Drawing.Point(12, 306)
        Me.picSquigglyn.Name = "picSquigglyn"
        Me.picSquigglyn.Size = New System.Drawing.Size(52, 40)
        Me.picSquigglyn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picSquigglyn.TabIndex = 10
        Me.picSquigglyn.TabStop = False
        '
        'picAt
        '
        Me.picAt.Image = CType(resources.GetObject("picAt.Image"), System.Drawing.Image)
        Me.picAt.Location = New System.Drawing.Point(70, 306)
        Me.picAt.Name = "picAt"
        Me.picAt.Size = New System.Drawing.Size(52, 40)
        Me.picAt.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picAt.TabIndex = 11
        Me.picAt.TabStop = False
        '
        'picAe
        '
        Me.picAe.Image = CType(resources.GetObject("picAe.Image"), System.Drawing.Image)
        Me.picAe.Location = New System.Drawing.Point(128, 306)
        Me.picAe.Name = "picAe"
        Me.picAe.Size = New System.Drawing.Size(52, 40)
        Me.picAe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picAe.TabIndex = 12
        Me.picAe.TabStop = False
        '
        'picMeltedthree
        '
        Me.picMeltedthree.Image = CType(resources.GetObject("picMeltedthree.Image"), System.Drawing.Image)
        Me.picMeltedthree.Location = New System.Drawing.Point(186, 306)
        Me.picMeltedthree.Name = "picMeltedthree"
        Me.picMeltedthree.Size = New System.Drawing.Size(52, 40)
        Me.picMeltedthree.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picMeltedthree.TabIndex = 13
        Me.picMeltedthree.TabStop = False
        '
        'picEuro
        '
        Me.picEuro.Image = CType(resources.GetObject("picEuro.Image"), System.Drawing.Image)
        Me.picEuro.Location = New System.Drawing.Point(244, 306)
        Me.picEuro.Name = "picEuro"
        Me.picEuro.Size = New System.Drawing.Size(52, 40)
        Me.picEuro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picEuro.TabIndex = 14
        Me.picEuro.TabStop = False
        '
        'picNwithhat
        '
        Me.picNwithhat.Image = CType(resources.GetObject("picNwithhat.Image"), System.Drawing.Image)
        Me.picNwithhat.Location = New System.Drawing.Point(12, 352)
        Me.picNwithhat.Name = "picNwithhat"
        Me.picNwithhat.Size = New System.Drawing.Size(52, 40)
        Me.picNwithhat.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picNwithhat.TabIndex = 15
        Me.picNwithhat.TabStop = False
        '
        'picDragon
        '
        Me.picDragon.Image = CType(resources.GetObject("picDragon.Image"), System.Drawing.Image)
        Me.picDragon.Location = New System.Drawing.Point(70, 352)
        Me.picDragon.Name = "picDragon"
        Me.picDragon.Size = New System.Drawing.Size(52, 40)
        Me.picDragon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picDragon.TabIndex = 16
        Me.picDragon.TabStop = False
        '
        'picQuestionmark
        '
        Me.picQuestionmark.Image = CType(resources.GetObject("picQuestionmark.Image"), System.Drawing.Image)
        Me.picQuestionmark.Location = New System.Drawing.Point(128, 352)
        Me.picQuestionmark.Name = "picQuestionmark"
        Me.picQuestionmark.Size = New System.Drawing.Size(52, 40)
        Me.picQuestionmark.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picQuestionmark.TabIndex = 17
        Me.picQuestionmark.TabStop = False
        '
        'picParagraph
        '
        Me.picParagraph.Image = CType(resources.GetObject("picParagraph.Image"), System.Drawing.Image)
        Me.picParagraph.Location = New System.Drawing.Point(186, 352)
        Me.picParagraph.Name = "picParagraph"
        Me.picParagraph.Size = New System.Drawing.Size(52, 40)
        Me.picParagraph.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picParagraph.TabIndex = 18
        Me.picParagraph.TabStop = False
        '
        'picRightc
        '
        Me.picRightc.Image = CType(resources.GetObject("picRightc.Image"), System.Drawing.Image)
        Me.picRightc.Location = New System.Drawing.Point(244, 352)
        Me.picRightc.Name = "picRightc"
        Me.picRightc.Size = New System.Drawing.Size(52, 40)
        Me.picRightc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picRightc.TabIndex = 19
        Me.picRightc.TabStop = False
        '
        'picLeftc
        '
        Me.picLeftc.Image = CType(resources.GetObject("picLeftc.Image"), System.Drawing.Image)
        Me.picLeftc.Location = New System.Drawing.Point(12, 398)
        Me.picLeftc.Name = "picLeftc"
        Me.picLeftc.Size = New System.Drawing.Size(52, 40)
        Me.picLeftc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picLeftc.TabIndex = 20
        Me.picLeftc.TabStop = False
        '
        'picPitchfork
        '
        Me.picPitchfork.Image = CType(resources.GetObject("picPitchfork.Image"), System.Drawing.Image)
        Me.picPitchfork.Location = New System.Drawing.Point(70, 398)
        Me.picPitchfork.Name = "picPitchfork"
        Me.picPitchfork.Size = New System.Drawing.Size(52, 40)
        Me.picPitchfork.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picPitchfork.TabIndex = 21
        Me.picPitchfork.TabStop = False
        '
        'picCursive
        '
        Me.picCursive.Image = CType(resources.GetObject("picCursive.Image"), System.Drawing.Image)
        Me.picCursive.Location = New System.Drawing.Point(128, 398)
        Me.picCursive.Name = "picCursive"
        Me.picCursive.Size = New System.Drawing.Size(52, 40)
        Me.picCursive.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picCursive.TabIndex = 22
        Me.picCursive.TabStop = False
        '
        'picTracks
        '
        Me.picTracks.Image = CType(resources.GetObject("picTracks.Image"), System.Drawing.Image)
        Me.picTracks.Location = New System.Drawing.Point(186, 398)
        Me.picTracks.Name = "picTracks"
        Me.picTracks.Size = New System.Drawing.Size(52, 40)
        Me.picTracks.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picTracks.TabIndex = 23
        Me.picTracks.TabStop = False
        '
        'picBalloon
        '
        Me.picBalloon.Image = CType(resources.GetObject("picBalloon.Image"), System.Drawing.Image)
        Me.picBalloon.Location = New System.Drawing.Point(244, 398)
        Me.picBalloon.Name = "picBalloon"
        Me.picBalloon.Size = New System.Drawing.Size(52, 40)
        Me.picBalloon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picBalloon.TabIndex = 24
        Me.picBalloon.TabStop = False
        '
        'picUpsidedowny
        '
        Me.picUpsidedowny.Image = CType(resources.GetObject("picUpsidedowny.Image"), System.Drawing.Image)
        Me.picUpsidedowny.Location = New System.Drawing.Point(12, 444)
        Me.picUpsidedowny.Name = "picUpsidedowny"
        Me.picUpsidedowny.Size = New System.Drawing.Size(52, 40)
        Me.picUpsidedowny.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picUpsidedowny.TabIndex = 25
        Me.picUpsidedowny.TabStop = False
        '
        'picBt
        '
        Me.picBt.Image = CType(resources.GetObject("picBt.Image"), System.Drawing.Image)
        Me.picBt.Location = New System.Drawing.Point(70, 444)
        Me.picBt.Name = "picBt"
        Me.picBt.Size = New System.Drawing.Size(52, 40)
        Me.picBt.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picBt.TabIndex = 26
        Me.picBt.TabStop = False
        '
        'picAns1
        '
        Me.picAns1.Location = New System.Drawing.Point(12, 529)
        Me.picAns1.Name = "picAns1"
        Me.picAns1.Size = New System.Drawing.Size(52, 40)
        Me.picAns1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picAns1.TabIndex = 27
        Me.picAns1.TabStop = False
        '
        'picAns2
        '
        Me.picAns2.Location = New System.Drawing.Point(88, 529)
        Me.picAns2.Name = "picAns2"
        Me.picAns2.Size = New System.Drawing.Size(52, 40)
        Me.picAns2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picAns2.TabIndex = 28
        Me.picAns2.TabStop = False
        '
        'picAns3
        '
        Me.picAns3.Location = New System.Drawing.Point(165, 529)
        Me.picAns3.Name = "picAns3"
        Me.picAns3.Size = New System.Drawing.Size(52, 40)
        Me.picAns3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picAns3.TabIndex = 29
        Me.picAns3.TabStop = False
        '
        'picAns4
        '
        Me.picAns4.Location = New System.Drawing.Point(244, 529)
        Me.picAns4.Name = "picAns4"
        Me.picAns4.Size = New System.Drawing.Size(52, 40)
        Me.picAns4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picAns4.TabIndex = 30
        Me.picAns4.TabStop = False
        '
        'lstKp
        '
        Me.lstKp.Location = New System.Drawing.Point(12, 28)
        Me.lstKp.Name = "lstKp"
        Me.lstKp.Size = New System.Drawing.Size(284, 180)
        Me.lstKp.TabIndex = 32
        Me.lstKp.UseCompatibleStateImageBehavior = False
        Me.lstKp.View = System.Windows.Forms.View.List
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(221, 444)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 40)
        Me.btnReset.TabIndex = 33
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton1, Me.lbl1})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(317, 25)
        Me.ToolStrip1.TabIndex = 35
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(36, 22)
        Me.ToolStripButton1.Text = "Root"
        '
        'lbl1
        '
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(0, 22)
        '
        'frmKeypads
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(317, 581)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.lstKp)
        Me.Controls.Add(Me.picAns4)
        Me.Controls.Add(Me.picAns3)
        Me.Controls.Add(Me.picAns2)
        Me.Controls.Add(Me.picAns1)
        Me.Controls.Add(Me.picBt)
        Me.Controls.Add(Me.picUpsidedowny)
        Me.Controls.Add(Me.picBalloon)
        Me.Controls.Add(Me.picTracks)
        Me.Controls.Add(Me.picCursive)
        Me.Controls.Add(Me.picPitchfork)
        Me.Controls.Add(Me.picLeftc)
        Me.Controls.Add(Me.picRightc)
        Me.Controls.Add(Me.picParagraph)
        Me.Controls.Add(Me.picQuestionmark)
        Me.Controls.Add(Me.picDragon)
        Me.Controls.Add(Me.picNwithhat)
        Me.Controls.Add(Me.picEuro)
        Me.Controls.Add(Me.picMeltedthree)
        Me.Controls.Add(Me.picAe)
        Me.Controls.Add(Me.picAt)
        Me.Controls.Add(Me.picSquigglyn)
        Me.Controls.Add(Me.picSix)
        Me.Controls.Add(Me.picHookn)
        Me.Controls.Add(Me.picPumpkin)
        Me.Controls.Add(Me.picSquidknife)
        Me.Controls.Add(Me.picOmega)
        Me.Controls.Add(Me.picDoublek)
        Me.Controls.Add(Me.picSmileyface)
        Me.Controls.Add(Me.picHollowstar)
        Me.Controls.Add(Me.picFilledstar)
        Me.Controls.Add(Me.picCopyright)
        Me.Name = "frmKeypads"
        Me.Text = "Keypads"
        CType(Me.picCopyright, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFilledstar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picHollowstar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSmileyface, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDoublek, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picOmega, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSquidknife, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPumpkin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picHookn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSix, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSquigglyn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAe, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMeltedthree, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEuro, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picNwithhat, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDragon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picQuestionmark, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picParagraph, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRightc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLeftc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPitchfork, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCursive, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTracks, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBalloon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picUpsidedowny, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAns1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAns2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAns3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAns4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picCopyright As System.Windows.Forms.PictureBox
    Friend WithEvents picFilledstar As System.Windows.Forms.PictureBox
    Friend WithEvents picHollowstar As System.Windows.Forms.PictureBox
    Friend WithEvents picSmileyface As System.Windows.Forms.PictureBox
    Friend WithEvents picDoublek As System.Windows.Forms.PictureBox
    Friend WithEvents picOmega As System.Windows.Forms.PictureBox
    Friend WithEvents picSquidknife As System.Windows.Forms.PictureBox
    Friend WithEvents picPumpkin As System.Windows.Forms.PictureBox
    Friend WithEvents picHookn As System.Windows.Forms.PictureBox
    Friend WithEvents picSix As System.Windows.Forms.PictureBox
    Friend WithEvents picSquigglyn As System.Windows.Forms.PictureBox
    Friend WithEvents picAt As System.Windows.Forms.PictureBox
    Friend WithEvents picAe As System.Windows.Forms.PictureBox
    Friend WithEvents picMeltedthree As System.Windows.Forms.PictureBox
    Friend WithEvents picEuro As System.Windows.Forms.PictureBox
    Friend WithEvents picNwithhat As System.Windows.Forms.PictureBox
    Friend WithEvents picDragon As System.Windows.Forms.PictureBox
    Friend WithEvents picQuestionmark As System.Windows.Forms.PictureBox
    Friend WithEvents picParagraph As System.Windows.Forms.PictureBox
    Friend WithEvents picRightc As System.Windows.Forms.PictureBox
    Friend WithEvents picLeftc As System.Windows.Forms.PictureBox
    Friend WithEvents picPitchfork As System.Windows.Forms.PictureBox
    Friend WithEvents picCursive As System.Windows.Forms.PictureBox
    Friend WithEvents picTracks As System.Windows.Forms.PictureBox
    Friend WithEvents picBalloon As System.Windows.Forms.PictureBox
    Friend WithEvents picUpsidedowny As System.Windows.Forms.PictureBox
    Friend WithEvents picBt As System.Windows.Forms.PictureBox
    Friend WithEvents picAns1 As System.Windows.Forms.PictureBox
    Friend WithEvents picAns2 As System.Windows.Forms.PictureBox
    Friend WithEvents picAns3 As System.Windows.Forms.PictureBox
    Friend WithEvents picAns4 As System.Windows.Forms.PictureBox
    Friend WithEvents lstKp As System.Windows.Forms.ListView
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl1 As System.Windows.Forms.ToolStripLabel

End Class
