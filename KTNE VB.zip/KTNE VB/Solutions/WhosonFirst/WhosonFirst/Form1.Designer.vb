﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WhosonFirst
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(WhosonFirst))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btnRoot = New System.Windows.Forms.ToolStripButton()
        Me.lblToolstrip = New System.Windows.Forms.ToolStripLabel()
        Me.txtDisplay = New System.Windows.Forms.TextBox()
        Me.picBlank = New System.Windows.Forms.PictureBox()
        Me.picC = New System.Windows.Forms.PictureBox()
        Me.picCee = New System.Windows.Forms.PictureBox()
        Me.picDisplay = New System.Windows.Forms.PictureBox()
        Me.picFirst = New System.Windows.Forms.PictureBox()
        Me.picHoldOn = New System.Windows.Forms.PictureBox()
        Me.picLead = New System.Windows.Forms.PictureBox()
        Me.picLed = New System.Windows.Forms.PictureBox()
        Me.picLeed = New System.Windows.Forms.PictureBox()
        Me.picNo = New System.Windows.Forms.PictureBox()
        Me.picNothing = New System.Windows.Forms.PictureBox()
        Me.picNull = New System.Windows.Forms.PictureBox()
        Me.picOkay = New System.Windows.Forms.PictureBox()
        Me.btnDisplayConfirm = New System.Windows.Forms.Button()
        Me.picRead = New System.Windows.Forms.PictureBox()
        Me.picRed = New System.Windows.Forms.PictureBox()
        Me.picReed = New System.Windows.Forms.PictureBox()
        Me.picSays = New System.Windows.Forms.PictureBox()
        Me.picSee = New System.Windows.Forms.PictureBox()
        Me.picTheir = New System.Windows.Forms.PictureBox()
        Me.picThere = New System.Windows.Forms.PictureBox()
        Me.picTheyAre = New System.Windows.Forms.PictureBox()
        Me.picTheyre = New System.Windows.Forms.PictureBox()
        Me.picYoure = New System.Windows.Forms.PictureBox()
        Me.picUr = New System.Windows.Forms.PictureBox()
        Me.picYes = New System.Windows.Forms.PictureBox()
        Me.picYouAre = New System.Windows.Forms.PictureBox()
        Me.picYou = New System.Windows.Forms.PictureBox()
        Me.picYour = New System.Windows.Forms.PictureBox()
        Me.txtMatch = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lstList = New System.Windows.Forms.ListView()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.ToolStrip1.SuspendLayout()
        CType(Me.picBlank, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCee, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFirst, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picHoldOn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLead, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLed, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLeed, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picNo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picNothing, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picNull, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picOkay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRead, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRed, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picReed, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSays, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSee, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTheir, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picThere, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTheyAre, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTheyre, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picYoure, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picUr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picYes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picYouAre, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picYou, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picYour, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(45, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(193, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Please type displayed word and confirm"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnRoot, Me.lblToolstrip})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(271, 25)
        Me.ToolStrip1.TabIndex = 1
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btnRoot
        '
        Me.btnRoot.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnRoot.Image = CType(resources.GetObject("btnRoot.Image"), System.Drawing.Image)
        Me.btnRoot.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnRoot.Name = "btnRoot"
        Me.btnRoot.Size = New System.Drawing.Size(36, 22)
        Me.btnRoot.Text = "Root"
        '
        'lblToolstrip
        '
        Me.lblToolstrip.Name = "lblToolstrip"
        Me.lblToolstrip.Size = New System.Drawing.Size(0, 22)
        '
        'txtDisplay
        '
        Me.txtDisplay.Location = New System.Drawing.Point(92, 41)
        Me.txtDisplay.Name = "txtDisplay"
        Me.txtDisplay.Size = New System.Drawing.Size(89, 20)
        Me.txtDisplay.TabIndex = 0
        '
        'picBlank
        '
        Me.picBlank.Image = CType(resources.GetObject("picBlank.Image"), System.Drawing.Image)
        Me.picBlank.Location = New System.Drawing.Point(92, 67)
        Me.picBlank.Name = "picBlank"
        Me.picBlank.Size = New System.Drawing.Size(89, 91)
        Me.picBlank.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picBlank.TabIndex = 3
        Me.picBlank.TabStop = False
        Me.picBlank.Visible = False
        '
        'picC
        '
        Me.picC.Image = CType(resources.GetObject("picC.Image"), System.Drawing.Image)
        Me.picC.Location = New System.Drawing.Point(92, 67)
        Me.picC.Name = "picC"
        Me.picC.Size = New System.Drawing.Size(89, 91)
        Me.picC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picC.TabIndex = 4
        Me.picC.TabStop = False
        Me.picC.Visible = False
        '
        'picCee
        '
        Me.picCee.Image = CType(resources.GetObject("picCee.Image"), System.Drawing.Image)
        Me.picCee.Location = New System.Drawing.Point(92, 67)
        Me.picCee.Name = "picCee"
        Me.picCee.Size = New System.Drawing.Size(89, 91)
        Me.picCee.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picCee.TabIndex = 5
        Me.picCee.TabStop = False
        Me.picCee.Visible = False
        '
        'picDisplay
        '
        Me.picDisplay.Image = CType(resources.GetObject("picDisplay.Image"), System.Drawing.Image)
        Me.picDisplay.Location = New System.Drawing.Point(92, 67)
        Me.picDisplay.Name = "picDisplay"
        Me.picDisplay.Size = New System.Drawing.Size(89, 91)
        Me.picDisplay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picDisplay.TabIndex = 6
        Me.picDisplay.TabStop = False
        Me.picDisplay.Visible = False
        '
        'picFirst
        '
        Me.picFirst.Image = CType(resources.GetObject("picFirst.Image"), System.Drawing.Image)
        Me.picFirst.Location = New System.Drawing.Point(92, 67)
        Me.picFirst.Name = "picFirst"
        Me.picFirst.Size = New System.Drawing.Size(89, 91)
        Me.picFirst.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picFirst.TabIndex = 7
        Me.picFirst.TabStop = False
        Me.picFirst.Visible = False
        '
        'picHoldOn
        '
        Me.picHoldOn.Image = CType(resources.GetObject("picHoldOn.Image"), System.Drawing.Image)
        Me.picHoldOn.Location = New System.Drawing.Point(92, 67)
        Me.picHoldOn.Name = "picHoldOn"
        Me.picHoldOn.Size = New System.Drawing.Size(89, 91)
        Me.picHoldOn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picHoldOn.TabIndex = 8
        Me.picHoldOn.TabStop = False
        Me.picHoldOn.Visible = False
        '
        'picLead
        '
        Me.picLead.Image = CType(resources.GetObject("picLead.Image"), System.Drawing.Image)
        Me.picLead.Location = New System.Drawing.Point(92, 67)
        Me.picLead.Name = "picLead"
        Me.picLead.Size = New System.Drawing.Size(89, 91)
        Me.picLead.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picLead.TabIndex = 9
        Me.picLead.TabStop = False
        Me.picLead.Visible = False
        '
        'picLed
        '
        Me.picLed.Image = CType(resources.GetObject("picLed.Image"), System.Drawing.Image)
        Me.picLed.Location = New System.Drawing.Point(92, 67)
        Me.picLed.Name = "picLed"
        Me.picLed.Size = New System.Drawing.Size(89, 91)
        Me.picLed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picLed.TabIndex = 10
        Me.picLed.TabStop = False
        Me.picLed.Visible = False
        '
        'picLeed
        '
        Me.picLeed.Image = CType(resources.GetObject("picLeed.Image"), System.Drawing.Image)
        Me.picLeed.Location = New System.Drawing.Point(92, 67)
        Me.picLeed.Name = "picLeed"
        Me.picLeed.Size = New System.Drawing.Size(89, 91)
        Me.picLeed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picLeed.TabIndex = 11
        Me.picLeed.TabStop = False
        Me.picLeed.Visible = False
        '
        'picNo
        '
        Me.picNo.Image = CType(resources.GetObject("picNo.Image"), System.Drawing.Image)
        Me.picNo.Location = New System.Drawing.Point(92, 67)
        Me.picNo.Name = "picNo"
        Me.picNo.Size = New System.Drawing.Size(89, 91)
        Me.picNo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picNo.TabIndex = 12
        Me.picNo.TabStop = False
        Me.picNo.Visible = False
        '
        'picNothing
        '
        Me.picNothing.Image = CType(resources.GetObject("picNothing.Image"), System.Drawing.Image)
        Me.picNothing.Location = New System.Drawing.Point(92, 67)
        Me.picNothing.Name = "picNothing"
        Me.picNothing.Size = New System.Drawing.Size(89, 91)
        Me.picNothing.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picNothing.TabIndex = 13
        Me.picNothing.TabStop = False
        Me.picNothing.Visible = False
        '
        'picNull
        '
        Me.picNull.Image = CType(resources.GetObject("picNull.Image"), System.Drawing.Image)
        Me.picNull.Location = New System.Drawing.Point(92, 67)
        Me.picNull.Name = "picNull"
        Me.picNull.Size = New System.Drawing.Size(89, 91)
        Me.picNull.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picNull.TabIndex = 14
        Me.picNull.TabStop = False
        Me.picNull.Visible = False
        '
        'picOkay
        '
        Me.picOkay.Image = CType(resources.GetObject("picOkay.Image"), System.Drawing.Image)
        Me.picOkay.Location = New System.Drawing.Point(92, 67)
        Me.picOkay.Name = "picOkay"
        Me.picOkay.Size = New System.Drawing.Size(89, 91)
        Me.picOkay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picOkay.TabIndex = 15
        Me.picOkay.TabStop = False
        Me.picOkay.Visible = False
        '
        'btnDisplayConfirm
        '
        Me.btnDisplayConfirm.Location = New System.Drawing.Point(92, 203)
        Me.btnDisplayConfirm.Name = "btnDisplayConfirm"
        Me.btnDisplayConfirm.Size = New System.Drawing.Size(89, 23)
        Me.btnDisplayConfirm.TabIndex = 2
        Me.btnDisplayConfirm.Text = "Confirm"
        Me.btnDisplayConfirm.UseVisualStyleBackColor = True
        '
        'picRead
        '
        Me.picRead.Image = CType(resources.GetObject("picRead.Image"), System.Drawing.Image)
        Me.picRead.Location = New System.Drawing.Point(92, 67)
        Me.picRead.Name = "picRead"
        Me.picRead.Size = New System.Drawing.Size(89, 91)
        Me.picRead.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picRead.TabIndex = 17
        Me.picRead.TabStop = False
        Me.picRead.Visible = False
        '
        'picRed
        '
        Me.picRed.Image = CType(resources.GetObject("picRed.Image"), System.Drawing.Image)
        Me.picRed.Location = New System.Drawing.Point(92, 67)
        Me.picRed.Name = "picRed"
        Me.picRed.Size = New System.Drawing.Size(89, 91)
        Me.picRed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picRed.TabIndex = 18
        Me.picRed.TabStop = False
        Me.picRed.Visible = False
        '
        'picReed
        '
        Me.picReed.Image = CType(resources.GetObject("picReed.Image"), System.Drawing.Image)
        Me.picReed.Location = New System.Drawing.Point(92, 67)
        Me.picReed.Name = "picReed"
        Me.picReed.Size = New System.Drawing.Size(89, 91)
        Me.picReed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picReed.TabIndex = 19
        Me.picReed.TabStop = False
        Me.picReed.Visible = False
        '
        'picSays
        '
        Me.picSays.Image = CType(resources.GetObject("picSays.Image"), System.Drawing.Image)
        Me.picSays.Location = New System.Drawing.Point(92, 67)
        Me.picSays.Name = "picSays"
        Me.picSays.Size = New System.Drawing.Size(89, 91)
        Me.picSays.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picSays.TabIndex = 20
        Me.picSays.TabStop = False
        Me.picSays.Visible = False
        '
        'picSee
        '
        Me.picSee.Image = CType(resources.GetObject("picSee.Image"), System.Drawing.Image)
        Me.picSee.Location = New System.Drawing.Point(92, 67)
        Me.picSee.Name = "picSee"
        Me.picSee.Size = New System.Drawing.Size(89, 91)
        Me.picSee.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picSee.TabIndex = 21
        Me.picSee.TabStop = False
        Me.picSee.Visible = False
        '
        'picTheir
        '
        Me.picTheir.Image = CType(resources.GetObject("picTheir.Image"), System.Drawing.Image)
        Me.picTheir.Location = New System.Drawing.Point(92, 67)
        Me.picTheir.Name = "picTheir"
        Me.picTheir.Size = New System.Drawing.Size(89, 91)
        Me.picTheir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picTheir.TabIndex = 22
        Me.picTheir.TabStop = False
        Me.picTheir.Visible = False
        '
        'picThere
        '
        Me.picThere.Image = CType(resources.GetObject("picThere.Image"), System.Drawing.Image)
        Me.picThere.Location = New System.Drawing.Point(92, 67)
        Me.picThere.Name = "picThere"
        Me.picThere.Size = New System.Drawing.Size(89, 91)
        Me.picThere.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picThere.TabIndex = 23
        Me.picThere.TabStop = False
        Me.picThere.Visible = False
        '
        'picTheyAre
        '
        Me.picTheyAre.Image = CType(resources.GetObject("picTheyAre.Image"), System.Drawing.Image)
        Me.picTheyAre.Location = New System.Drawing.Point(92, 67)
        Me.picTheyAre.Name = "picTheyAre"
        Me.picTheyAre.Size = New System.Drawing.Size(89, 91)
        Me.picTheyAre.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picTheyAre.TabIndex = 24
        Me.picTheyAre.TabStop = False
        Me.picTheyAre.Visible = False
        '
        'picTheyre
        '
        Me.picTheyre.Image = CType(resources.GetObject("picTheyre.Image"), System.Drawing.Image)
        Me.picTheyre.Location = New System.Drawing.Point(92, 67)
        Me.picTheyre.Name = "picTheyre"
        Me.picTheyre.Size = New System.Drawing.Size(89, 91)
        Me.picTheyre.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picTheyre.TabIndex = 25
        Me.picTheyre.TabStop = False
        Me.picTheyre.Visible = False
        '
        'picYoure
        '
        Me.picYoure.Image = CType(resources.GetObject("picYoure.Image"), System.Drawing.Image)
        Me.picYoure.Location = New System.Drawing.Point(92, 67)
        Me.picYoure.Name = "picYoure"
        Me.picYoure.Size = New System.Drawing.Size(89, 91)
        Me.picYoure.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picYoure.TabIndex = 26
        Me.picYoure.TabStop = False
        Me.picYoure.Visible = False
        '
        'picUr
        '
        Me.picUr.Image = CType(resources.GetObject("picUr.Image"), System.Drawing.Image)
        Me.picUr.Location = New System.Drawing.Point(92, 67)
        Me.picUr.Name = "picUr"
        Me.picUr.Size = New System.Drawing.Size(89, 91)
        Me.picUr.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picUr.TabIndex = 27
        Me.picUr.TabStop = False
        Me.picUr.Visible = False
        '
        'picYes
        '
        Me.picYes.Image = CType(resources.GetObject("picYes.Image"), System.Drawing.Image)
        Me.picYes.Location = New System.Drawing.Point(92, 67)
        Me.picYes.Name = "picYes"
        Me.picYes.Size = New System.Drawing.Size(89, 91)
        Me.picYes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picYes.TabIndex = 28
        Me.picYes.TabStop = False
        Me.picYes.Visible = False
        '
        'picYouAre
        '
        Me.picYouAre.Image = CType(resources.GetObject("picYouAre.Image"), System.Drawing.Image)
        Me.picYouAre.Location = New System.Drawing.Point(92, 67)
        Me.picYouAre.Name = "picYouAre"
        Me.picYouAre.Size = New System.Drawing.Size(89, 91)
        Me.picYouAre.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picYouAre.TabIndex = 29
        Me.picYouAre.TabStop = False
        Me.picYouAre.Visible = False
        '
        'picYou
        '
        Me.picYou.Image = CType(resources.GetObject("picYou.Image"), System.Drawing.Image)
        Me.picYou.Location = New System.Drawing.Point(92, 67)
        Me.picYou.Name = "picYou"
        Me.picYou.Size = New System.Drawing.Size(89, 91)
        Me.picYou.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picYou.TabIndex = 30
        Me.picYou.TabStop = False
        Me.picYou.Visible = False
        '
        'picYour
        '
        Me.picYour.Image = CType(resources.GetObject("picYour.Image"), System.Drawing.Image)
        Me.picYour.Location = New System.Drawing.Point(92, 67)
        Me.picYour.Name = "picYour"
        Me.picYour.Size = New System.Drawing.Size(89, 91)
        Me.picYour.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picYour.TabIndex = 31
        Me.picYour.TabStop = False
        Me.picYour.Visible = False
        '
        'txtMatch
        '
        Me.txtMatch.Location = New System.Drawing.Point(92, 177)
        Me.txtMatch.Name = "txtMatch"
        Me.txtMatch.Size = New System.Drawing.Size(89, 20)
        Me.txtMatch.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(45, 161)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(192, 13)
        Me.Label2.TabIndex = 33
        Me.Label2.Text = "Please type matching word and confirm"
        '
        'lstList
        '
        Me.lstList.HideSelection = False
        Me.lstList.Location = New System.Drawing.Point(77, 232)
        Me.lstList.Name = "lstList"
        Me.lstList.Size = New System.Drawing.Size(121, 222)
        Me.lstList.TabIndex = 34
        Me.lstList.UseCompatibleStateImageBehavior = False
        Me.lstList.View = System.Windows.Forms.View.List
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(92, 460)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(89, 23)
        Me.btnReset.TabIndex = 3
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'WhosonFirst
        '
        Me.AcceptButton = Me.btnDisplayConfirm
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(271, 491)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.lstList)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtMatch)
        Me.Controls.Add(Me.picYour)
        Me.Controls.Add(Me.picYou)
        Me.Controls.Add(Me.picYouAre)
        Me.Controls.Add(Me.picYes)
        Me.Controls.Add(Me.picUr)
        Me.Controls.Add(Me.picYoure)
        Me.Controls.Add(Me.picTheyre)
        Me.Controls.Add(Me.picTheyAre)
        Me.Controls.Add(Me.picThere)
        Me.Controls.Add(Me.picTheir)
        Me.Controls.Add(Me.picSee)
        Me.Controls.Add(Me.picSays)
        Me.Controls.Add(Me.picReed)
        Me.Controls.Add(Me.picRed)
        Me.Controls.Add(Me.picRead)
        Me.Controls.Add(Me.btnDisplayConfirm)
        Me.Controls.Add(Me.picOkay)
        Me.Controls.Add(Me.picNull)
        Me.Controls.Add(Me.picNothing)
        Me.Controls.Add(Me.picNo)
        Me.Controls.Add(Me.picLeed)
        Me.Controls.Add(Me.picLed)
        Me.Controls.Add(Me.picLead)
        Me.Controls.Add(Me.picHoldOn)
        Me.Controls.Add(Me.picFirst)
        Me.Controls.Add(Me.picDisplay)
        Me.Controls.Add(Me.picCee)
        Me.Controls.Add(Me.picC)
        Me.Controls.Add(Me.picBlank)
        Me.Controls.Add(Me.txtDisplay)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "WhosonFirst"
        Me.Text = "Who's on First"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        CType(Me.picBlank, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCee, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFirst, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picHoldOn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLead, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLed, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLeed, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picNo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picNothing, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picNull, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picOkay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRead, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRed, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picReed, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSays, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSee, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTheir, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picThere, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTheyAre, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTheyre, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picYoure, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picUr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picYes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picYouAre, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picYou, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picYour, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents btnRoot As System.Windows.Forms.ToolStripButton
    Friend WithEvents txtDisplay As System.Windows.Forms.TextBox
    Friend WithEvents picBlank As System.Windows.Forms.PictureBox
    Friend WithEvents picC As System.Windows.Forms.PictureBox
    Friend WithEvents picCee As System.Windows.Forms.PictureBox
    Friend WithEvents picDisplay As System.Windows.Forms.PictureBox
    Friend WithEvents picFirst As System.Windows.Forms.PictureBox
    Friend WithEvents picHoldOn As System.Windows.Forms.PictureBox
    Friend WithEvents picLead As System.Windows.Forms.PictureBox
    Friend WithEvents picLed As System.Windows.Forms.PictureBox
    Friend WithEvents picLeed As System.Windows.Forms.PictureBox
    Friend WithEvents picNo As System.Windows.Forms.PictureBox
    Friend WithEvents picNothing As System.Windows.Forms.PictureBox
    Friend WithEvents picNull As System.Windows.Forms.PictureBox
    Friend WithEvents picOkay As System.Windows.Forms.PictureBox
    Friend WithEvents btnDisplayConfirm As System.Windows.Forms.Button
    Friend WithEvents picRead As System.Windows.Forms.PictureBox
    Friend WithEvents picRed As System.Windows.Forms.PictureBox
    Friend WithEvents picReed As System.Windows.Forms.PictureBox
    Friend WithEvents picSays As System.Windows.Forms.PictureBox
    Friend WithEvents picSee As System.Windows.Forms.PictureBox
    Friend WithEvents picTheir As System.Windows.Forms.PictureBox
    Friend WithEvents picThere As System.Windows.Forms.PictureBox
    Friend WithEvents picTheyAre As System.Windows.Forms.PictureBox
    Friend WithEvents picTheyre As System.Windows.Forms.PictureBox
    Friend WithEvents picYoure As System.Windows.Forms.PictureBox
    Friend WithEvents picUr As System.Windows.Forms.PictureBox
    Friend WithEvents picYes As System.Windows.Forms.PictureBox
    Friend WithEvents picYouAre As System.Windows.Forms.PictureBox
    Friend WithEvents picYou As System.Windows.Forms.PictureBox
    Friend WithEvents picYour As System.Windows.Forms.PictureBox
    Friend WithEvents txtMatch As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lstList As System.Windows.Forms.ListView
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents lblToolstrip As System.Windows.Forms.ToolStripLabel

End Class
